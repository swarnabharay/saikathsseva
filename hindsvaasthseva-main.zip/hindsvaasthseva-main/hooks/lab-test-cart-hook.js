import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { toast } from "sonner";

const useLabTestCart = create(
  persist(
    (set, get) => ({
      items: [],
      
      addItem: (test) => {
        const currentItems = get().items;
        const existingItem = currentItems.find(item => item.labId === test.labId);

        if (existingItem) {
          const updatedItems = currentItems.map(item =>
            item.labId === test.labId
              ? { ...item, quantity: item.quantity + 1 }
              : item
          );
          set({ items: updatedItems });
          toast.success("Test quantity updated");
        } else {
          set({ items: [...currentItems, { ...test, quantity: 1 }] });
          toast.success("Test added to cart");
        }
      },

      removeItem: (labId) => {
        set({ items: get().items.filter(item => item.labId !== labId) });
        toast.success("Test removed from cart");
      },

      clearCart: () => {
        set({ items: [] });
        toast.success("Cart cleared");
      },

      updateQuantity: (labId, quantity) => {
        if (quantity < 1) {
          toast.error("Quantity must be at least 1");
          return;
        }

        const updatedItems = get().items.map(item =>
          item.labId === labId ? { ...item, quantity } : item
        );
        set({ items: updatedItems });
        toast.success("Quantity updated");
      },

      getTotal: () => {
        return get().items.reduce(
          (total, item) => total + item.price * item.quantity,
          0
        );
      },
    }),
    {
      name: "lab-test-cart",
      storage: createJSONStorage(() => localStorage),
    }
  )
);

export default useLabTestCart;