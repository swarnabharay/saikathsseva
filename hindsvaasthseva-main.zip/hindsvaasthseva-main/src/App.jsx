import AvailableDepartments from "./components/Home/AvailableDepartments";
import Hero from "./components/Home/Hero";
import NearestInstitution from "./components/Home/NearestInstitution";
import { useEffect } from "react";
import isTokenExpired from "./services/checkTokenExpiry";

function App() {

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (isTokenExpired(token)) {
      console.log("Token expired. Logging out...");
      localStorage.removeItem("token");
    }
  }, []);

  return (
    <>
      <Hero/>
      <NearestInstitution/>
      <AvailableDepartments/>
    </>
  );
}

export default App;