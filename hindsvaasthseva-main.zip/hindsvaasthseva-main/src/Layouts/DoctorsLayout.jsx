import { Outlet } from "react-router-dom";

function DoctorsLayout() {
  return (
    <>
      <Outlet />
    </>
  );
}

export default DoctorsLayout;
