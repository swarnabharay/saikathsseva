import TopBar from "../components/TopBar";
import { Outlet } from "react-router-dom";
import Footer from "../components/footer";
function Layout() {
  return(
    <>
    <TopBar/>
    {/* <TopBarSmall/> */}
    <Outlet/>
    <Footer/>
    </>
  )
}

export default Layout;