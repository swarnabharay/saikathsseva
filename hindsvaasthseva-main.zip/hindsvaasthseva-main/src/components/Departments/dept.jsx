import React from 'react';
// import { useRouter } from 'next/router';
// import { useRouter } from 'react-router-dom';
const departments = [
  { 
    id: 1, 
    name: 'Emergency', 
    description: 'Our Emergency department provides 24/7 medical services, ensuring immediate and efficient care for critical conditions.', 
    details: 'The Emergency department is equipped with advanced life-saving equipment and a highly skilled team of doctors and nurses. We prioritize patient safety and rapid diagnosis to stabilize and treat emergencies effectively.',
    image: '/images/emergency.png', 
    route: '/departments/emergency' 
  },
  { 
    id: 2, 
    name: 'Healthcare', 
    description: 'Comprehensive healthcare services to promote wellness and manage chronic conditions.', 
    details: 'Our Healthcare department offers personalized medical care with a focus on preventive measures and patient education. From regular checkups to managing chronic illnesses, we ensure holistic well-being.',
    image: '/images/healthcare.png', 
    route: '/departments/healthcare' 
  },
  { 
    id: 3, 
    name: 'Laboratory', 
    description: 'Advanced diagnostic services with state-of-the-art equipment.', 
    details: 'The Laboratory department provides accurate and timely diagnostic testing, supporting the diagnosis and treatment of various medical conditions. Our team ensures precision and reliability in every test.',
    image: '/images/laboratory.png', 
    route: '/departments/laboratory' 
  },
  { 
    id: 4, 
    name: 'Radiology', 
    description: 'State-of-the-art imaging services for accurate diagnosis.', 
    details: 'Radiology services include X-rays, MRI, CT scans, and ultrasounds. Our cutting-edge imaging technology and experienced radiologists ensure clear and precise results.',
    image: '/images/radiology.png', 
    route: '/departments/radiology' 
  },
  { 
    id: 5, 
    name: 'Pharmacy', 
    description: 'On-site medication dispensary for your convenience.', 
    details: 'Our Pharmacy department provides a wide range of medications with a focus on patient education and safety. Our pharmacists ensure you receive the correct prescriptions and dosage instructions.',
    image: '/images/pharmacy.png', 
    route: '/departments/pharmacy' 
  },
];

const Departments = () => {
//   const router = useRouter();

//   const handleNavigation = (route) => {
//     router.push(route);
//   };

  return (
    <div className="bg-gray-100 py-10">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center text-red-700 mb-8">Our Departments</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {departments.map((dept) => (
            <div
              key={dept.id}
              className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300 cursor-pointer"
            //   onClick={() => handleNavigation(dept.route)}
            >
              <img
                src={dept.image}
                alt={dept.name}
                className="w-full h-40 object-cover"
              />
              <div className="p-4">
                <h2 className="text-xl font-semibold text-red-700 mb-2">{dept.name}</h2>
                <p className="text-gray-600 text-sm">{dept.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Departments;
