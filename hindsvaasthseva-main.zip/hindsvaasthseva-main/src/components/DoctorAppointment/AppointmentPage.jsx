import { useState } from "react";
import { useParams } from "react-router-dom";
import { useEffect } from "react";
import { getHospitalById } from "../../services/apis/hospitalApis";

import {
  FaChevronLeft,
  FaChevronRight,
  FaStethoscope,
  FaPills,
} from "react-icons/fa";
import { bookAppointment } from "../../services/apis/bookingApis";

const AppointmentPage = () => {
  const { doctorId, hospitalId } = useParams();
  const [isLoading, setIsLoading] = useState(false);
  const [hospital, setHospital] = useState(null);

  // fetch hospital data to get hospital name
  useEffect(() => {
    const fetchHospital = async () => {
      try {
        setIsLoading(true);
        const response = await getHospitalById(hospitalId);
        setHospital(response.data);
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching hospitals:", error);
        setIsLoading(false);
      }
    };

    fetchHospital();
  }, [hospitalId]);

  // State to track the selected date
  const [selectedDate, setSelectedDate] = useState(new Date());
  // State to track the selected time slot
  const [selectedTime, setSelectedTime] = useState(null);

  // Function to get the first day of the month (0-6 where 0 is Sunday)
  const getFirstDayOfMonth = (year, month) => new Date(year, month, 1).getDay();

  // Function to get the total number of days in a month
  const getDaysInMonth = (year, month) =>
    new Date(year, month + 1, 0).getDate();

  // Handle month navigation (previous or next month)
  const handleMonthChange = (direction) => {
    const newDate = new Date(
      selectedDate.getFullYear(),
      selectedDate.getMonth() + direction
    );
    setSelectedDate(newDate);
  };

  // Extract month and year from the selected date
  const month = selectedDate.getMonth();
  const year = selectedDate.getFullYear();

  // Get the total days in the current month
  const daysInMonthCount = getDaysInMonth(year, month);
  // Get the first day of the current month
  const firstDay = getFirstDayOfMonth(year, month);

  // Generate an array of days to display in the calendar
  const daysArray = Array(firstDay)
    .fill(null) // Fill empty spaces for days before the first day of the month
    .concat(Array.from({ length: daysInMonthCount }, (_, i) => i + 1));

  // Handle selecting a date from the calendar
  const handleDateSelect = (day) => {
    const selected = new Date(year, month, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Reset time for accurate comparison

    if (selected >= today) {
      setSelectedDate(selected);
    } else {
      alert("You cannot select a past date!");
    }
  };

  // Handle selecting a time slot
  const handleTimeSlotSelect = (time) => {
    setSelectedTime(time);
    console.log("Selected date and time:", {
      date: selectedDate.toLocaleDateString(),
      time,
    });
  };

  // Handle the "Next" button click
  const handleBooking = async (doctorId) => {
    if (selectedTime) {
      console.log("Final Selected date and time:", {
        date: selectedDate.toLocaleDateString(),
        time: selectedTime,
      });
      const userId = Number(localStorage.getItem("userId"));
      console.log("Payload being sent:", { userId, doctorId });
      await bookAppointment({ userId, doctorId });
    } else {
      alert("Please select a time slot.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center py-10">
      {/* Title */}
      <h2 className="text-2xl font-bold mb-6">Confirm Booking</h2>

      {/* Main Container */}
      <div className="w-full max-w-5xl bg-white rounded-lg shadow-lg p-6 flex flex-col md:flex-row space-y-6 md:space-y-0 md:space-x-6 text-primary font-bold">
        {/* Left Section: Doctor and Hospital Info */}
        <div className="w-full md:w-1/2">
          <div className="space-y-4">
            {isLoading ? (
              <div className="flex justify-center items-center h-32">
                <div className="spinner-border animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <p className="flex items-center space-x-2">
                Hospital name: {hospital?.hospital.hospitalName}
              </p>
            )}
            <h2 className=" font-bold flex items-center">
              <FaStethoscope className="mr-2" /> {doctorId}
            </h2>
            <p className="text-lg font-bold flex items-center gap-3">
              <FaPills />
              Consultion Fee:
              <span>Rs. {doctorId}/-</span>
            </p>
          </div>
        </div>

        {/* Right Section: Calendar and Time Slots */}
        <div className="w-full md:w-1/2 border-t md:border-t-0 md:border-l pt-6 md:pt-0 pl-0 md:pl-6">
          <h3 className="text-lg font-bold mb-4 text-black">
            Select Date and Time:
          </h3>

          {/* Month Navigation */}
          <div className="flex justify-between items-center mb-4">
            <button
              onClick={() => handleMonthChange(-1)}
              className="material-icons"
            >
              <FaChevronLeft />
            </button>
            <p className="text-lg font-semibold">
              {selectedDate.toLocaleDateString("en-GB", {
                month: "long",
                year: "numeric",
              })}
            </p>
            <button
              onClick={() => handleMonthChange(1)}
              className="material-icons"
            >
              <FaChevronRight />
            </button>
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-2 mb-4">
            {/* Weekday Labels */}
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <p key={day} className="text-center font-bold text-primary">
                {day}
              </p>
            ))}
            {/* Days */}
            {daysArray.map((day, index) =>
              day ? (
                <button
                  key={index}
                  onClick={() => handleDateSelect(day)}
                  className={`h-10 w-10 rounded-full text-sm ${
                    selectedDate.getDate() === day &&
                    selectedDate.getMonth() === month &&
                    selectedDate.getFullYear() === year
                      ? "bg-primary text-secondary font-bold"
                      : "hover:bg-gray-200 text-black"
                  }`}
                  disabled={
                    new Date(year, month, day) < new Date().setHours(0, 0, 0, 0) // Disable past dates
                  }
                  style={{
                    opacity:
                      new Date(year, month, day) <
                      new Date().setHours(0, 0, 0, 0)
                        ? 0.5
                        : 1,
                    cursor:
                      new Date(year, month, day) <
                      new Date().setHours(0, 0, 0, 0)
                        ? "not-allowed"
                        : "pointer",
                  }}
                >
                  {day}
                </button>
              ) : (
                <div key={index}></div> // Empty div for blank spaces
              )
            )}
          </div>

          {/* Selected Date Display */}
          <h4 className="font-bold mb-2">
            {selectedDate.toLocaleDateString("en-GB", {
              weekday: "long",
              day: "numeric",
              month: "long",
            })}
          </h4>

          {/* Time Slots */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {[
              // List of available time slots
              "10:30am",
              "11:30am",
              "02:30pm",
              "03:00pm",
              "03:30pm",
              "04:30pm",
              "05:00pm",
              "05:30pm",
            ].map((time) => (
              <button
                key={time} // Use time as key since times are unique
                onClick={() => handleTimeSlotSelect(time)}
                className={`py-2 px-4 rounded-lg ${
                  selectedTime === time // Check against selectedTime state
                    ? "bg-primary text-secondary"
                    : "border hover:bg-white font-semibold bg-secondary text-primary"
                }`}
              >
                {time}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Next Button */}
      <button
        onClick={() => handleBooking(doctorId)}
        className="bg-primary text-secondary px-6 py-2 rounded-lg mt-6 font-semibold"
      >
        Continue to Pay Rs. {doctorId}
      </button>
    </div>
  ); // Return null until doctor data is available
};

export default AppointmentPage;
