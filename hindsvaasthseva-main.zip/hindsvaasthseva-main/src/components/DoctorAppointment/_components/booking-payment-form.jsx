import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const bookingFormSchema = z.object({
  patientName: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  contactNumber: z
    .string()
    .regex(/^\+?\d{10,12}$/, "Please enter a valid phone number"),
  problem: z.string().min(1, "Please select your problem"),

  cardNumber: z.string().length(16, "Card number must be 16 digits").optional(),
  cardName: z.string().min(2, "Name must be at least 2 characters").optional(),
  expiryDate: z
    .string()
    .regex(
      /^(0[1-9]|1[0-2])\/([0-9]{2})$/,
      "Expiry date must be in MM/YY format"
    )
    .optional(),
  cvv: z
    .string()
    .length(3, "CVV must be 3 digits")
    .regex(/^[0-9]+$/, "CVV must contain only digits")
    .optional(),
});

const BookingPaymentForm = ({ bookingDetails }) => {
  const [paymentMethod, setPaymentMethod] = useState("creditCard");

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      patientName: "",
      email: "",
      contactNumber: "",
      problem: "",
      cardNumber: "",
      cardName: "",
      expiryDate: "",
      cvv: "",
    },
  });

  const handlePaymentMethodChange = (method) => {
    setPaymentMethod(method);
  };

  const onSubmit = (data) => {
    const paymentData = {
      personalInfo: {
        patientName: data.patientName,
        email: data.email,
        contactNumber: data.contactNumber,
        problem: data.problem,
      },
      bookingInfo: {
        doctorName: bookingDetails.doctorName,
        appointmentDate: bookingDetails.date,
        appointmentTime: bookingDetails.time,
        fees: bookingDetails.fees,
      },
      paymentMethod,
      ...(paymentMethod === "creditCard" && {
        paymentDetails: {
          cardNumber: data.cardNumber,
          cardName: data.cardName,
          expiryDate: data.expiryDate,
          cvv: data.cvv,
        },
      }),
    };

    console.log("Booking Payment Submission:", paymentData);
    // Here you would submit paymentData to your backend
  };

  return (
    <div className="w-full max-w-screen-2xl min-h-screen 2xl:pt-10 px-5 md:px-14 mx-auto">
      <h2 className="text-2xl font-bold mb-6">Confirm Booking</h2>
      <div className="flex w-full md:flex-row flex-col gap-10 2xl:gap-28">
        {/* doctor details */}
        <div className="md:w-[50%] w-full flex flex-col gap-5">
          <Link
            to={"/"}
            className="p-2 w-fit rounded-full bg-secondary text-primary border border-primary/50"
          >
            <ArrowLeft />
          </Link>
          <div className="flex flex-col gap-3 bg-secondary/50 p-4 rounded-lg shadow-lg">
            <h3 className="text-primary">Dr: </h3>
            <span className="text-lg text-primary">Time: </span>
            <span className="text-lg text-primary">Specialist: </span>
            <span className="text-lg text-primary">Fees: </span>
          </div>
        </div>
        {/* form details */}
        <div className="md:w-[50%] w-full p-4 border border-primary rounded-lg">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Personal Information Section */}
            <div className="space-y-4">
              <h3 className="text-xl font-semibold">Enter Details</h3>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Patient's Name
                </label>
                <input
                  {...register("patientName")}
                  className="w-full p-2 border rounded-lg"
                  placeholder="Enter patient name"
                />
                {errors.patientName && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.patientName.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <input
                  {...register("email")}
                  className="w-full p-2 border rounded-lg"
                  placeholder="Enter email"
                />
                {errors.email && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.email.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Contact Number
                </label>
                <input
                  {...register("contactNumber")}
                  className="w-full p-2 border rounded-lg"
                  placeholder="Enter contact number"
                />
                {errors.contactNumber && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.contactNumber.message}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Problem
                </label>
                <select
                  {...register("problem")}
                  className="w-full p-2 border rounded-lg"
                >
                  <option value="">Select problem</option>
                  <option value="consultation">General Consultation</option>
                  <option value="followup">Follow-up Visit</option>
                  <option value="emergency">Emergency</option>
                </select>
                {errors.problem && (
                  <p className="text-red-500 text-sm mt-1">
                    {errors.problem.message}
                  </p>
                )}
              </div>
            </div>

            {/* Payment Method Selection */}
            <div className="space-y-4">
              <h3 className="text-xl font-semibold">Payment Details</h3>

              <div className="space-y-2">
                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="creditCard"
                    checked={paymentMethod === "creditCard"}
                    onChange={() => handlePaymentMethodChange("creditCard")}
                    className="form-radio"
                  />
                  <span>Credit Card</span>
                </label>

                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="paypal"
                    checked={paymentMethod === "paypal"}
                    onChange={() => handlePaymentMethodChange("paypal")}
                    className="form-radio"
                  />
                  <span>PayPal</span>
                </label>

                <label className="flex items-center gap-2">
                  <input
                    type="radio"
                    value="paytm"
                    checked={paymentMethod === "paytm"}
                    onChange={() => handlePaymentMethodChange("paytm")}
                    className="form-radio"
                  />
                  <span>Paytm</span>
                </label>
              </div>
            </div>

            {/* Credit Card Form */}
            {paymentMethod === "creditCard" && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Card Number
                  </label>
                  <input
                    {...register("cardNumber")}
                    className="w-full p-2 border rounded-lg"
                    placeholder="XXXX XXXX XXXX XXXX"
                  />
                  {errors.cardNumber && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.cardNumber.message}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">
                    Name on Card
                  </label>
                  <input
                    {...register("cardName")}
                    className="w-full p-2 border rounded-lg"
                    placeholder="Enter name on card"
                  />
                  {errors.cardName && (
                    <p className="text-red-500 text-sm mt-1">
                      {errors.cardName.message}
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">
                      Expiry Date
                    </label>
                    <input
                      {...register("expiryDate")}
                      className="w-full p-2 border rounded-lg"
                      placeholder="MM/YY"
                    />
                    {errors.expiryDate && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.expiryDate.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-1">
                      CVV
                    </label>
                    <input
                      {...register("cvv")}
                      type="password"
                      className="w-full p-2 border rounded-lg"
                      placeholder="XXX"
                    />
                    {errors.cvv && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.cvv.message}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-primary text-white py-3 rounded-lg font-semibold"
            >
              Confirm Payment
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default BookingPaymentForm;
