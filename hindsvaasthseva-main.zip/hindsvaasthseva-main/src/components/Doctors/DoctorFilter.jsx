import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";

const DoctorFilter = ({ availableDoctors, choosenHospitalId }) => {
  const navigate = useNavigate();

  // Check if filters are not applied yet
  if (!choosenHospitalId) {
    return (
      <div className="m-10 text-center text-gray-600">
        <h3 className="text-2xl font-semibold">Please select a hospital and department to view available doctors.</h3>
      </div>
    );
  }

  // When no doctors are available for the applied filters
  if (!availableDoctors.length) {
    return (
      <h3 className="m-10 text-center text-gray-600">
        Sorry! We could not find any doctor for the specific department in this Hospital.
      </h3>
    );
  }

  // When doctors are available
  return (
    <div className="p-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {availableDoctors.map((doctor) => (
          <div
            key={doctor.id}
            className="border shadow-lg p-4 text-start bg-primary text-secondary rounded-xl"
          >
            <img
              src={doctor.image || "https://via.placeholder.com/100"}
              alt={doctor.name}
              className="w-24 h-24 rounded-full mb-4 mx-auto"
            />
            <h2 className="text-xl font-bold">{doctor.name}</h2>
            <p>Category: {doctor.category}</p>
            <p>Specialization: {doctor.specialization}</p>
            <p>Fees: ₹{doctor.consultation}</p>
            <button
              className="bg-secondary text-primary font-bold rounded-lg px-3 py-1 mt-3"
              onClick={() => navigate(`/book-appointment/${doctor.id}/${choosenHospitalId}`)}
            >
              Book Appointment
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

DoctorFilter.propTypes = {
  choosenHospitalId: PropTypes.number,
  availableDoctors: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.number.isRequired,
      name: PropTypes.string.isRequired,
      category: PropTypes.string.isRequired,
      consultation: PropTypes.number.isRequired,
    })
  ).isRequired,
};

export default DoctorFilter;
