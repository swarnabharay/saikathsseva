import { useEffect, useState } from "react";
import DoctorFilter from "./DoctorFilter";
import {
  getAllAvailableDepartments,
  getAllHospital,
} from "../../services/apis/hospitalApis";

function DoctorsPage() {
  const [departments, setDepartments] = useState([]);
  const [hospitals, setHospitals] = useState([]);
  const [choosenHospitalId, setChoosenHospitalId] = useState();
  const [choosenDepartmentId, setChoosenDepartmentId] = useState();
  const [isLoading, setIsLoading] = useState(false);
  const [availableDoctors, setAvailableDoctors] = useState([]);

  // Fetch departments
  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const response = await getAllAvailableDepartments();
        setDepartments(response.data);
      } catch (error) {
        console.error("Error fetching departments:", error);
      }
    };

    fetchDepartments();
  }, []);

  // Fetch hospitals
  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        setIsLoading(true);
        const response = await getAllHospital();
        setHospitals(response.data);
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching hospitals:", error);
        setIsLoading(false);
      }
    };

    fetchHospitals();
  }, []);

  // Update available doctors when hospitalId or departmentId changes
  useEffect(() => {
    if (choosenHospitalId && choosenDepartmentId) {
      const hospital = hospitals.find(
        (h) => h.hospitalId === Number(choosenHospitalId)
      );
      const department = hospital?.Departments?.find(
        (d) => d.deptId === Number(choosenDepartmentId)
      );
      setAvailableDoctors(department?.Doctors || []);
    } else {
      setAvailableDoctors([]);
    }
  }, [choosenHospitalId, choosenDepartmentId, hospitals]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="spinner-border animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <section className="w-full p-6">
      <div className="bg-secondary rounded-lg p-6 flex flex-col items-center shadow-md">
        <h2 className="pb-5 text-primary">Search for Doctors Below</h2>
        <div className="flex flex-col lg:flex-row w-full gap-6">
          {/* Department Selector */}
          <div className="w-full lg:w-1/2">
            <select
              id="department-select"
              className="w-full p-3 rounded-lg border border-gray-300"
              value={choosenDepartmentId}
              onChange={(e) => setChoosenDepartmentId(e.target.value)}
            >
              <option value="">Select Department</option>
              {departments.map((department) => (
                <option key={department.deptId} value={department.deptId}>
                  {department.deptName}
                </option>
              ))}
            </select>
          </div>

          {/* Hospital Selector */}
          <div className="w-full lg:w-1/2">
            <select
              id="hospital-select"
              className="w-full p-3 rounded-lg border border-gray-300"
              value={choosenHospitalId}
              onChange={(e) => setChoosenHospitalId(e.target.value)}
            >
              <option value="">Select Hospital</option>
              {hospitals.map((hospital) => (
                <option key={hospital.hospitalId} value={hospital.hospitalId}>
                  {hospital.hospitalName}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Pass choosenHospitalId and choosenDepartmentId to DoctorFilter */}
        <DoctorFilter
          availableDoctors={availableDoctors}
          choosenHospitalId={Number(choosenHospitalId)}
        />
      </div>
    </section>
  );
}

export default DoctorsPage;
