import { useEffect } from "react";
import { getAllAvailableDepartments } from "../../services/apis/hospitalApis";
import { useState } from "react";

function AvailableDepartments() {
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    // Fetch departments from the server
    try {
      const fetchDepartments = async () => {
        const response = await getAllAvailableDepartments();
        setDepartments(response.data);
      };

      fetchDepartments();
    } catch (error) {
      console.log(error);
    }
  }, []);

  return (
    <section className="w-full py-8">
      <h1 className="text-start pb-8">
        <span className="text-black">Available</span> Departments
      </h1>
      <div
        className="flex flex-row overflow-x-auto gap-5"
        style={{
          scrollbarWidth: "none",
          msOverflowStyle: "none",
          WebkitScrollbar: "none", // For Webkit browsers like Chrome
        }}
      >
        {departments.map((department) => (
          <div key={department.deptId} className="flex flex-col items-center">
            <div className="flex flex-col items-center justify-center rounded-full bg-gray-300 w-24 h-24 md:w-32 md:h-32 overflow-hidden">
              {/* Placeholder for Icon */}
              <div className="w-full h-full">
                <img
                  src={department.deptImage}
                  alt={department.deptName}
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
            <p className="text-primary font-bold">{department.deptName}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default AvailableDepartments;
