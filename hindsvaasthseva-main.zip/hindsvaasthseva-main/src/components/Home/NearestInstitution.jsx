import Button from "../reusable/Button";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { getAllHospital } from "../../services/apis/hospitalApis";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationDot } from "@fortawesome/free-solid-svg-icons";
import RowPlaceHolder from "../reusable/placeholder/_rowPlaceholder";

function NearestInstitution() {
  const [hospitals, setHospitals] = useState([]);
  const [isLoading, setIsLoading] = useState([false]);

  // Array of hospital information
  useEffect(() => {
    const fetchHospital = async () => {
      try {
        setIsLoading(true);
        const response = await getAllHospital();
        console.log(response.data);
        setHospitals(response.data);
        setIsLoading(false);
      } catch (error) {
        console.log(error);
        setIsLoading(false);
      }
    };

    fetchHospital();
  }, []);

  return (
    <section className="py-7 md:py-14 flex flex-col w-full">
      {/* Heading with View All button */}
      <div className="flex flex-row pb-5 justify-between items-center">
        <h1>
          Institutions <span className="text-black">near you</span>
        </h1>
        <Link to={"/search-doctors"}>
          <Button>View all</Button>
        </Link>
      </div>

      {/* All Hospital cards */}
      {isLoading ? (
        <RowPlaceHolder />
      ) : hospitals.length > 0 ? (
        <div
          className="grid grid-cols-1 md:grid-cols-3 gap-5 overflow-x-hidden"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            WebkitScrollbar: "none", // For Webkit browsers like Chrome
          }}
        >
          {hospitals.map((hospital, index) => (
            <div key={hospital.hospitalId} className="px-2 py-2 rounded-3xl overflow-hidden flex-shrink-0">
              <Link to={`/hospitalinfo/${hospital.hospitalId}`}>
                <div
                  className={`pb-5 rounded-3xl w-[200px] md:w-[295px] h-full flex flex-col items-start justify-between ${
                    index % 2 === 0
                      ? "bg-primary text-secondary"
                      : "bg-secondary text-black"
                  } shadow-md`}
                >
                  <div className="h-[200px] w-full">
                    <img
                      src={hospital.imageUrl}
                      alt={`${hospital.hospitalName} image`}
                      className="rounded-t-3xl w-full h-full"
                    />
                  </div>
                  <div className="w-11/12 px-5 md:px-7 pt-5 md:py-4">
                    <h3>{hospital.hospitalName}</h3>
                  </div>
                  <div>
                    <div className="font-bold flex flex-row text-center items-center gap-2 px-5 md:px-7">
                      <FontAwesomeIcon icon={faLocationDot} />
                      <h4>{hospital.location}</h4>
                    </div>
                    <div className="font-bold px-5 md:px-7">
                      <div className="font-bold pt-1">
                        {hospital.Departments ? (
                          hospital.Departments.length > 0 ? (
                            <h4>{hospital.Departments[0]?.deptName}</h4>
                          ) : (
                            "No departments available"
                          )
                        ) : (
                          "No departments available"
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      ) : (
        <div className="w-full h-10 text-center">No hospitals found</div>
      )}
    </section>
  );
}

export default NearestInstitution;
