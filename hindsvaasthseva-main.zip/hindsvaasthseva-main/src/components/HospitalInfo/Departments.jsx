import AvailableDepartments from "../Home/AvailableDepartments";

function Departments() {
  return (
    <>
      <AvailableDepartments />
    </>
  );
}

export default Departments;
