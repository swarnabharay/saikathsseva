import { useState, useEffect } from "react";
import { getAllHospital } from "../../services/apis/hospitalApis";
import { Link } from "react-router-dom";
import { useParams } from "react-router-dom";

function HospitalInfo() {
  const { id } = useParams();
  const [hospital, setHospital] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch hospital information
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const response = await getAllHospital({
          token: localStorage.getItem("token"),
        });
        const hospitalsData = response.data;

        // Find and set the hospital that matches the given id
        const selectedHospital = hospitalsData.find(
          (h) => h.hospitalId === Number(id)
        );
        setHospital(selectedHospital);

        setIsLoading(false);
      } catch (error) {
        console.error(error);
        setIsLoading(false);
      }
    };

    fetchData();
  }, [id]);

  // Loading circular bar
  if (isLoading) {
    return (
      <div className="flex justify-center items-center w-screen h-screen">
        <div className="spinner-border animate-spin inline-block w-8 h-8 border-4 border-solid border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  // If there is no hospital
  if (!hospital) {
    return <div className="flex justify-center items-center h-screen">Hospital not found</div>;
  }

  return (
    <div className="h-full w-full bg-gray-50">
      <section className="max-w-screen-lg mx-auto my-10 px-4 sm:px-8">

        {/* Hospital Image */}
        <div className="w-full h-64 sm:h-80 mb-8">
          <img
            src={hospital.imageUrl}
            alt="Hospital"
            className="object-fill h-full rounded-lg shadow-lg"
          />
        </div>

        <div className="flex flex-col gap-6">

          {/* Name and Book Now Button */}
          <div className="flex justify-between items-center w-full">
            <h2 className="text-3xl font-bold text-primary">{hospital.hospitalName}</h2>
            <Link to="/search-doctors"> 
              <button className="text-white font-bold bg-primary hover:bg-primary-dark px-8 py-3 rounded-full">
                Search Doctors
              </button>
            </Link>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2 text-lg text-gray-700">
            <span>Rating: </span>
            <span className="font-semibold">{hospital.rating} Star</span>
          </div>

          {/* Highlights */}
          <div className="flex justify-start w-full">
            <div className="bg-secondary shadow-md rounded-lg w-full lg:w-2/3 p-6">
              <h3 className="mb-4">Highlights</h3>
              <p className="text-gray-700">{hospital.highlights}</p>
            </div>
          </div>

          {/* Location on Map */}
          <div className="flex justify-center lg:justify-start w-full">
            <div className="bg-white shadow-md rounded-lg w-full lg:w-2/3 p-6 mt-6">
              <h3 className="mb-4">Location</h3>
              <p className="text-gray-700">{hospital.about}</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default HospitalInfo;
