import React from "react";
import useLabTestCart from "../../../../hooks/lab-test-cart-hook";

const LabTestCard = ({ test }) => {
  const { items, addItem, removeItem } = useLabTestCart();
  const isInCart = items.some(item => item.labId === test.labId);

  const handleToggle = () => {
    if (isInCart) {
      removeItem(test.labId);
    } else {
      addItem(test);
    }
  };

  return (
    <div className="bg-secondary rounded-3xl overflow-hidden shadow-sm cursor-pointer transition-all flex flex-col justify-between w-full aspect-square p-4">
      <div className="flex flex-col">
        <div className="h-10 w-full mb-3 overflow-hidden rounded-2xl">
          <img 
            src={`/api/placeholder/400/320`} 
            alt={test.serviceName}
            className="w-full h-full object-cover"
          />
        </div>
        <h3 className="font-semibold mb-2">{test.serviceName}</h3>
        <p className="text-sm text-gray-600 mb-2">Includes 12 tests</p>
      </div>
      <div className="flex items-center justify-between">
        <div className="font-bold mt-auto text-lg">Rs. {test.price}/-</div>
        <button
          onClick={handleToggle}
          className={`py-2 px-[1rem] text-center font-extrabold rounded-2xl text-xl w-fit ${
            isInCart
              ? "bg-red-500 text-black hover:bg-red-400"
              : "bg-red-400 text-black hover:bg-red-500"
          }`}
        >
          {isInCart ? "Remove" : "Add"}
        </button>
      </div>
    </div>
  );
};

export default LabTestCard;