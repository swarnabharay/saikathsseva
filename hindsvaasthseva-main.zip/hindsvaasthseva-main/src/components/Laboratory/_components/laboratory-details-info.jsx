import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { laboratories, laboratoryLabServices, labTests } from "../../../constants/dummy";
import LabTestCard from "./lab-test-card";
import TestSummary from "./selected-test-summary";
import LaboratoryInfo from "./laboratory-info";

const LaboratoryInfoPage = () => {
  const { id } = useParams();
  const [laboratory, setLaboratory] = useState(null);
  const [availableTests, setAvailableTests] = useState([]);
  const [selectedTests, setSelectedTests] = useState([]);

  useEffect(() => {
    // Find the laboratory with the matching ID
    const foundLaboratory = laboratories.find(h => h.laboratoryId === id);
    setLaboratory(foundLaboratory);

    // Get available tests for this laboratory
    if (laboratoryLabServices[id]) {
      const testsForLaboratory = laboratoryLabServices[id].map(labId => 
        labTests.find(test => test.labId === labId)
      ).filter(Boolean);
      setAvailableTests(testsForLaboratory);
    }
  }, [id]);

  const toggleTestSelection = (labId) => {
    if (selectedTests.includes(labId)) {
      setSelectedTests(selectedTests.filter(id => id !== labId));
    } else {
      setSelectedTests([...selectedTests, labId]);
    }
  };

  if (!laboratory) {
    return <div className="w-full min-h-screen flex justify-center items-center">Loading...</div>;
  }

  return (
    <div className="w-full min-h-screen flex flex-col gap-10 justify-center items-center mx-auto px-5 md:px-14 max-w-screen-2xl">
      <LaboratoryInfo laboratory={laboratory} />

      <h2 className="text-4xl font-bold mb-6">Book Lab Tests</h2>
      <div className="w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {availableTests.map(test => (
          <LabTestCard
            key={test.labId}
            test={test}
            isSelected={selectedTests.includes(test.labId)}
            onToggleSelection={toggleTestSelection}
          />
        ))}
      </div>

      <TestSummary/>
    </div>
  );
};

export default LaboratoryInfoPage;