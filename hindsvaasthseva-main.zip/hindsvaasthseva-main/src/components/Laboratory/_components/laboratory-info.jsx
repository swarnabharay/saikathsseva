import React from "react";

const LaboratoryInfo = ({ laboratory }) => {
  if (!laboratory) return null;

  return (
    <div className="w-full">
      <h1 className="text-4xl font-bold text-primary mb-4">{laboratory.laboratoryName}</h1>
      <div className="flex items-center mb-2">
        <span className="mr-2">📍</span>
        <p className="text-lg">{laboratory.location}</p>
      </div>
      <div className="flex items-center mb-4">
        <span className="mr-2">⭐</span>
        <p className="text-lg">{laboratory.rating}/5.0</p>
      </div>
      <p className="mb-4">{laboratory.description}</p>
      <div className="bg-[#fcf9e7] p-4 rounded-lg mb-8">
        <h3 className="font-semibold mb-2 text-primary">Highlights</h3>
        <p className="text-primary2">{laboratory.highlights}</p>
      </div>
    </div>
  );
};

export default LaboratoryInfo;