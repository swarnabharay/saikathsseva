import React from "react";
import NearestLaboratorys from "./nearest-laboratory";

const NearByClinic = () => {
  return (
    <div className="w-full flex flex-col gap-10 items-center">
      <div className="w-full text-center">
        <h1 className="text-5xl font-bold font-gilroy text-primary">
          <span className="text-black"> Find Test by </span>
          Health Concerns
        </h1>
      </div>
      <div className="w-full flex flex-col gap-6">
        <div className="w-full md:text-start text-center">
          <h1 className="text-3xl font-bold font-gilroy text-primary">
            <span className="text-black">Nearby</span> Clinics
          </h1>
          <div className="w-full mt-5">
            <NearestLaboratorys />
          </div>
        </div>
      </div>
    </div>
  );
};

export default NearByClinic;
