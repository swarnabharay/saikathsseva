import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faLocationDot } from "@fortawesome/free-solid-svg-icons";
import RowPlaceHolder from "../../reusable/placeholder/_rowPlaceholder";
import { useEffect, useState } from "react";
import { getAllLaboratories } from "../../../services/apis/laboratoryServices";

function NearestLaboratories() {
  const [laboratories, setLaboratories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchLaboratories = async () => {
      try {
        setIsLoading(true);
        const response = await getAllLaboratories();
        console.log(response.data);
        if (response.data && response.data.laboratories) {
          setLaboratories(response.data.laboratories);
        } else {
          console.error("Invalid response format:", response.data);
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error("Error fetching laboratories:", error);
        setIsLoading(false);
      }
    };

    fetchLaboratories();
  }, []);

  return (
    <section className="flex flex-col w-full">
      {isLoading ? (
        <RowPlaceHolder/>
      ) : laboratories.length > 0 ? (
        <div
          className="grid grid-cols-1 md:grid-cols-3 gap-5 overflow-x-hidden"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
            WebkitScrollbar: "none",
          }}
        >
          {laboratories.map((laboratory, index) => (
            <div key={laboratory.labId} className="px-2 py-2 rounded-3xl overflow-hidden flex-shrink-0">
              <Link to={`/laboratory/${laboratory.labId}`}>
                <div
                  className={`pb-5 rounded-3xl w-full h-full flex flex-col items-start justify-between ${
                    index % 2 === 0
                      ? "bg-primary text-secondary"
                      : "bg-secondary text-black"
                  } shadow-md`}
                >
                  <div className="h-[200px] rounded-3xl w-full bg-gray-200">
                    <div className="rounded-t-3xl w-full h-full flex items-center justify-center text-gray-500">
                      {laboratory.name} Image
                    </div>
                  </div>
                  <div className="w-11/12 px-5 md:px-7 pt-5 md:py-4">
                    <h3 className="font-semibold text-lg">{laboratory.name}</h3>
                  </div>
                  <div className="w-full">
                    <div className="font-bold flex flex-row text-center items-center gap-2 px-5 md:px-7">
                      <FontAwesomeIcon icon={faLocationDot} />
                      <h4 className="text-sm">{laboratory.address}</h4>
                    </div>
                    <div className="font-bold px-5 md:px-7">
                      <div className="font-bold pt-1">
                        <h4 className="text-sm">{laboratory.services.split(',')[0]}</h4>
                      </div>
                    </div>
                    <div className="px-5 md:px-7 mt-2 text-xs">
                      <p>{laboratory.status === "open" ? "Open Now" : "Closed"}</p>
                      <p>{laboratory.openingHours} - {laboratory.closingHours}</p>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      ) : (
        <div className="w-full h-10 text-center">No laboratories found</div>
      )}
    </section>
  );
}

export default NearestLaboratories;