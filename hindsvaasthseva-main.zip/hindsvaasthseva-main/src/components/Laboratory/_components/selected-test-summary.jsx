import React from 'react';
import { useNavigate } from 'react-router-dom';
import useLabTestCart from '../../../../hooks/lab-test-cart-hook';

const TestSummary = () => {
  const navigate = useNavigate();
  const { items, getTotal } = useLabTestCart();

  if (items.length === 0) {
    return null;
  }

  const handleProceed = () => {
    navigate('/book-now');
  };

  return (
    <div className="w-full bg-white shadow-lg p-6 border-t">
      <div className="w-full max-w-4xl mx-auto">
        <h3 className="text-xl font-bold mb-4">Selected Tests</h3>
        <div className="max-h-48 overflow-y-auto mb-4">
          {items.map((item) => (
            <div key={item.labId} className="flex justify-between items-center mb-2">
              <div className="flex items-center gap-2">
                <span>{item.serviceName}</span>
                {item.quantity > 1 && (
                  <span className="text-sm text-gray-500">× {item.quantity}</span>
                )}
              </div>
              <span>Rs. {item.price * item.quantity}/-</span>
            </div>
          ))}
        </div>
        
        <div className="border-t border-gray-200 mt-4 pt-4 flex justify-between font-bold">
          <span>Total:</span>
          <span>Rs. {getTotal()}/-</span>
        </div>
        
        <button 
          className="w-full bg-red-500 text-white py-3 rounded-full mt-6 font-semibold hover:bg-red-600 transition-colors"
          onClick={handleProceed}
        >
          Proceed to Book ({items.length} {items.length === 1 ? 'test' : 'tests'})
        </button>
      </div>
    </div>
  );
};

export default TestSummary;