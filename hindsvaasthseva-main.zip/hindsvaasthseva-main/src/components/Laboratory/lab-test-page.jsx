import React from 'react'
import Hero from '../Home/Hero'
import NearByClinic from './_components/near-by-clinic'

const LabtestPage = () => {
  return (
    <div className='w-full max-w-screen-2xl mx-auto px-5 md:px-8 flex flex-col items-center gap-10'>
      <Hero/>
      <NearByClinic/>
    </div>
  )
}

export default LabtestPage
