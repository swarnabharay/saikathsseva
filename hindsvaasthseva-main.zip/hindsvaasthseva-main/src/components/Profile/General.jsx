import { useState, useEffect } from "react";
import { getUser, updateUser } from "../../services/apis/userApis";
import { FaSignOutAlt } from "react-icons/fa";

const onLogout = () => {
  localStorage.removeItem("token");
  localStorage.removeItem("userEmail");
  window.location.href = "/";
};

const ProfileEditor = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [userData, setUserData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getUserData = async () => {
      try {
        const response = await getUser({
          token: localStorage.getItem("token"),
          email: localStorage.getItem("userEmail"),
        });
        setUserData(response.data);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    getUserData();
  }, []);

  // calculate the age from DOB
  const parseDateFromDDMMYYYY = (dob) => {
    if (!dob) return ""; // Handle missing DOB gracefully
    const day = parseInt(dob.slice(0, 2), 10);
    const month = parseInt(dob.slice(2, 4), 10); // Month is 0-indexed
    const year = parseInt(dob.slice(4, 8), 10);
    return new Date(year, month, day);
  };

  function calculateAge(dateString) {
    if (dateString.length < 8) {
      return 0;
    }
    const birthDate = parseDateFromDDMMYYYY(dateString);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    // Adjust age if the birthday hasn't occurred yet this year
    const hasBirthdayPassed =
      today.getMonth() > birthDate.getMonth() ||
      (today.getMonth() === birthDate.getMonth() &&
        today.getDate() >= birthDate.getDate());

    if (!hasBirthdayPassed) {
      age--;
    }
    return age;
  }

  // function formatDateToYYYYMMDD(date) {
  //   // Remove any non-digit characters
  //   let value = date.replace(/\D/g, "");

  //   // Ensure the input has 8 characters (ddmmyyyy format)
  //   if (value.length !== 8) {
  //     return ""; // Return empty string for invalid input
  //   }

  //   // Extract parts of the date
  //   const day = value.slice(0, 2);
  //   const month = value.slice(2, 4);
  //   const year = value.slice(4);

  //   // Return formatted date in YYYY-MM-DD
  //   return `${year}-${month}-${day}`;
  // }

  //handle input change
  
  
const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevData) => {
      const updatedData = { ...prevData, [name]: value };
      if (name === "dateOfBirth") {
        updatedData.age = calculateAge(value);
      }
      return updatedData;
    });
  };

  // Handle save after edit
  const handleSave = () => {
    const data = {
      name: userData.name,
      age: userData.age,
      phoneNumber: userData.phoneNumber,
      address: userData.address,
      email: userData.email,
      weight: userData.weight,
    };

    const updateUserData = async () => {
      try {
        await updateUser({
          token: localStorage.getItem("token"),
          email: localStorage.getItem("userEmail"),
          data,
        });
        window.location.reload();
      } catch (error) {
        console.error(error);
      }
    };
    updateUserData();
    setIsEditing(false);
  };

  // function addDateSeparators(date) {
  //   // Remove any non-digit characters
  //   let value = date.replace(/\D/g, "");

  //   // Ensure the input has at least 8 characters (ddmmyyyy format)
  //   if (value.length !== 8) {
  //     return "Invalid input"; // Handle cases where the input length is not valid
  //   }

  //   // Extract parts of the date
  //   const day = value.slice(0, 2);
  //   const month = value.slice(2, 4);
  //   const year = value.slice(4);

  //   // Rearrange to mm-dd-yyyy format
  //   return `${month}-${day}-${year}`;
  // }

  // Loading circular bar
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="spinner-border animate-spin inline-block w-8 h-8 border-4 border-solid border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  // Content after loading
  return (
    <div>
      <div className="max-w-5xl mx-auto mt-8 p-6 border rounded-lg shadow-lg bg-white">
        {/* Heading */}
        <h1 className="text-3xl font-bold text-center mb-6">Your Profile</h1>

        {/* Name and Age */}
        <div className="text-center mb-8">
          <div className="inline-block bg-gray-200 rounded-full h-24 w-24 mb-4"></div>
          <h2 className="text-2xl font-semibold">
            {userData.name} 
            {/* (
            {userData.dateOfBirth
              ? calculateAge(userData.dateOfBirth)
              : "Age not available"}{" "}
            years) */}
          </h2>
        </div>

        {/* Name */}
        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-bold">Name:</label>
            {isEditing ? (
              <input
                type="text"
                name="name"
                value={userData.name || ""}
                onChange={handleInputChange}
                className="w-full border rounded p-2"
              />
            ) : (
              <p>{userData.name}</p>
            )}
          </div>
          {/* <div>
            <label className="block text-sm font-bold" htmlFor="birthdate">
              Date Of Birth:
            </label>
            {isEditing ? (
              <input
                type="text"
                placeholder="DD-MM-YYYY"
                name="dateOfBirth"
                value={
                  userData.dateOfBirth
                    ? userData.dateOfBirth.split("-").reverse().join("-")
                    : ""
                }
                maxLength={10}
                onChange={handleInputChange}
                className="w-full border rounded p-2"
              />
            ) : (
              <p>
                {userData.dateOfBirth
                  ? new Date(userData.dateOfBirth).toLocaleDateString("en-GB")
                  : "Not provided"}
              </p>
            )}
          </div> */}

          {/* Phone number */}
          <div>
            <label className="block text-sm font-bold">Phone Number:</label>
            {isEditing ? (
              <input
                type="text"
                name="phoneNumber"
                value={userData.phoneNumber || ""}
                onChange={handleInputChange}
                className="w-full border rounded p-2"
              />
            ) : (
              <p>{userData.phoneNumber}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <label className="block font-bold text-bold">Email:</label>
            <div>
              <p>{userData.email}</p>
              <p className="text-xs text-red-600">
                Email can&apos;t be changed
              </p>
            </div>
          </div>

          {/* Weight */}
          <div>
            <label className="block text-sm font-bold">Your weight:</label>
            {isEditing ? (
              <input
                type="number"
                name="weight"
                value={userData.weight || ""}
                onChange={handleInputChange}
                className="w-full border rounded p-2"
              />
            ) : (
              <p>{userData.weight} Kg</p>
            )}
          </div>
          {/* Address */}
          <div className="col-span-2">
            <label className="block text-sm font-bold">Address:</label>
            {isEditing ? (
              <input
                type="text"
                name="address"
                value={userData.address || ""}
                onChange={handleInputChange}
                className="w-full border rounded p-2"
              />
            ) : (
              <p>{userData.address}</p>
            )}
          </div>
        </div>

        {/* Save and Logout buttons */}
        <div className="mt-8 flex justify-between items-center">
          <button
            className="bg-primary text-secondary px-10 py-2 rounded-full"
            onClick={isEditing ? handleSave : () => setIsEditing(true)}
          >
            {isEditing ? "Save" : "Edit"}
          </button>
          <button
            className="bg-red-600 flex flex-row text-center justify-center rounded-lg text-white items-center px-10 py-2"
            onClick={onLogout}
          >
            Logout
            <FaSignOutAlt className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileEditor;
