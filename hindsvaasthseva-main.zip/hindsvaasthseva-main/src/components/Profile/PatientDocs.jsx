import { useEffect, useState } from "react";
import { getUser } from "../../services/apis/userApis";

function PatientDocuments() {
  const [userData, setUserData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getUserData = async () => {
      try {
        const response = await getUser({
          token: localStorage.getItem("token"),
          email: localStorage.getItem("userEmail"),
        });
        setUserData(response.data);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    getUserData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="spinner-border animate-spin inline-block w-8 h-8 border-4 border-solid border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 max-w-4xl mx-auto">
      {/* Heading */}
      <h2 className="text-xl sm:text-2xl font-bold text-center mb-6">
        Your Documents
      </h2>

      {/* Documents List */}
      <div className="bg-white border-gray-200 border-2 rounded-xl p-4 sm:p-6">
        {userData.Prescriptions.length > 0 ? (
          <div className="space-y-4">
            {userData.Prescriptions.map((prescription, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row items-start md:items-center justify-between bg-gray-50 border border-gray-200 rounded-lg p-4"
              >
                <div className="flex-1 mb-4 sm:mb-0">
                  <h3 className="text-lg font-semibold">
                    {prescription.prepId}
                  </h3>
                  <p className="text-gray-500 text-xs">
                    Uploaded on:{" "}
                    {new Date(prescription.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center space-x-2 font-semibold">
                  <a
                    target="_blank"
                    href={prescription.presUrl}
                    className="px-3 py-1 bg-primary text-secondary rounded-lg text-md hover:bg-secondary-dark transition"
                  >
                    View Prescription
                  </a>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-600">No documents available.</p>
        )}
      </div>
    </div>
  );
}

export default PatientDocuments;
