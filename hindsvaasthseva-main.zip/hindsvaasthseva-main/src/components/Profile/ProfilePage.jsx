import { useState } from "react";
import General from "./General";
import ConsultionHistory from "./ConsultionHistory";
import PatientDocuments from "./PatientDocs";

function ProfilePage() {
  const [selectedProfileOption, setSelectedProfileOption] = useState("General");

  return (
    <div className="py-6 max-w-4xl mx-auto">
      {/* Tabs */}
      <div className="flex flex-row justify-start gap-2 sm:gap-4 mb-6">
        <button
          className={`${
            selectedProfileOption === "General"
              ? "px-2 sm:px-4 py-1 sm:py-2 bg-primary text-secondary rounded-full font-semibold text-sm sm:text-base"
              : "px-2 sm:px-4 py-1 sm:py-2 border-primary border text-primary rounded-full font-semibold text-sm sm:text-base"
          }`}
          onClick={() => setSelectedProfileOption("General")}
        >
          General
        </button>
        <button
          className={`${
            selectedProfileOption === "Consultion History"
              ? "px-2 sm:px-4 py-1 sm:py-2 bg-primary text-secondary rounded-full font-semibold text-sm sm:text-base"
              : "px-2 sm:px-4 py-1 sm:py-2 border-primary border text-primary rounded-full font-semibold text-sm sm:text-base"
          }`}
          onClick={() => setSelectedProfileOption("Consultion History")}
        >
          Consultation History
        </button>
        <button
          className={`${
            selectedProfileOption === "Patient Documents"
              ? "px-2 sm:px-4 py-1 sm:py-2 bg-primary text-secondary rounded-full font-semibold text-sm sm:text-base"
              : "px-2 sm:px-4 py-1 sm:py-2 border-primary border text-primary rounded-full font-semibold text-sm sm:text-base"
          }`}
          onClick={() => setSelectedProfileOption("Patient Documents")}
        >
          Your Documents
        </button>
      </div>

      {/* Conditional Rendering */}
      <div className="content">
        {selectedProfileOption === "General" && <General />}
        {selectedProfileOption === "Consultion History" && (
          <ConsultionHistory />
        )}
        {selectedProfileOption === "Patient Documents" && <PatientDocuments />}
      </div>
    </div>
  );
}

export default ProfilePage;
