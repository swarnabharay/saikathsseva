import { Link } from "react-router-dom";
//@ts-ignore
import Logo from "/logo.png";
//@ts-ignore
import LocationIcon from "../assets/location_icon.svg";
import { FaBookMedical, FaSearch, FaUser } from "react-icons/fa";
import { useEffect, useRef, useState } from "react";
import { getUser } from "../services/apis/userApis";
import React from "react";

export default function TopBar() {
  const [name, setName] = useState<string>("");
  const [searchResult, setSearchResult] = useState<string[]>([]);
  const searchBoxRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (localStorage.getItem("token") && localStorage.getItem("userEmail")) {
      const fetchData = async () => {
        try {
          const response = await getUser({
            token: localStorage.getItem("token")!,
            email: localStorage.getItem("userEmail")!,
          });

          if (response) {
            // console.log(response.data);
            const { name, id } = response.data;
            setName(name);
            localStorage.setItem("userId", id);
          } else {
            // Handle case when response is undefined, if needed
            console.error("No response returned from getUser.");
          }
        } catch (error) {
          console.error("Error:", error);
        }
      };

      fetchData();
    }
  }, []);

  // Close the dropdown if clicked outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        searchBoxRef.current &&
        !searchBoxRef.current.contains(event.target as Node)
      ) {
        setSearchResult([]); // Close the dropdown
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <nav className="flex text-sm font-bold justify-center top-5 left-2 right-2 fixed px-4 md:px-8 z-10">
      <div className="max-w-screen-lg w-full flex flex-row items-center px-2 md:px-6 py-2 md:py-3 bg-secondary rounded-lg shadow-lg space-x-2 md:space-x-3">
        {/* Logo */}
        <div className="w-auto">
          <Link to="/">
            <img
              src={Logo}
              alt="Logo"
              className="h-8 md:h-10 md:px-2"
            />
          </Link>
        </div>

        {/* Location */}
        <div className="hidden md:flex flex-row px-1 items-center space-x-2 w-auto">
          <img src={LocationIcon} alt="location_icon" className="h-5" />
          <div className="flex flex-col">
            <div className="font-bold">Select Location</div>
            <div className="text-primary font-bold">Kolkata</div>
          </div>
        </div>

        {/* Search Box */}
        <div className="relative flex-1 px-4 md:px-8" ref={searchBoxRef}>
          {/* Search input box */}
          <input
            type="text"
            placeholder="Search for doctors, specialties, or services..."
            className="w-full py-3 text-sm border border-gray-300 rounded-full pr-12 pl-4 focus:outline-none focus:ring-2 focus:ring-accent shadow-md"
            onFocus={() => setSearchResult(["hi", "hello"])} // Simulating search result on focus
          />

          {/* Search results dropdown */}
          {searchResult.length > 0 ? (
            <div className="w-full absolute top-12 z-10 bg-white rounded-xl shadow-lg max-h-80 overflow-y-auto mt-2">
              {searchResult.map((result, index) => (
                <Link
                  key={index}
                  to={"/search-doctors"}
                  className="block px-4 py-3 text-sm text-gray-700 hover:bg-primary hover:text-white transition-all duration-200"
                >
                  {result}
                </Link>
              ))}
            </div>
          ) : null}

          {/* Search icon */}
          <div className="absolute bg-primary rounded-full p-3 right-4 md:right-6 top-1/2 transform -translate-y-1/2 shadow-lg cursor-pointer hover:bg-accent transition-all duration-200">
            <FaSearch
              size={20}
              color="#fff"
              onClick={() => setSearchResult(["hi", "hello"])}
            />
          </div>
        </div>

        {/* Orders */}
        <Link to={"/orders"} className="w-auto">
          <div className="flex items-center space-x-2">
            <FaBookMedical size={18} />
            <div className="hidden md:block hover:text-primary">
              Your Bookings
            </div>
          </div>
        </Link>

        {/* Login/Signup */}
        <Link to="/profile" className="w-auto">
          <div className="flex items-center space-x-2">
            <FaUser size={18} />
            <div className="hidden md:block">
              {localStorage.getItem("userEmail")
                ? `Hi ${name}`
                : "Login/Signup"}
            </div>
          </div>
        </Link>
      </div>
    </nav>
  );
}
