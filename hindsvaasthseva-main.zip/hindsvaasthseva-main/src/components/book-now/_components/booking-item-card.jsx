import { Trash2 } from "lucide-react";

export const BookingItemCard = ({
  labId,
  serviceName,
  price,
  quantity,
  handleQuantityChange,
  removeItem,
}) => {
  return (
    <div className="border rounded-lg p-4 shadow-sm">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="font-semibold text-lg">{serviceName}</h3>
          <p className="text-gray-700">Rs. {price}/-</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex border border-primary rounded">
            <button
              onClick={() => handleQuantityChange(labId, quantity - 1)}
              className="text-primary lg:py-2 py-1 lg:px-3 px-2 border-primary border-r font-bold"
            >
              -
            </button>
            <span className="lg:py-2 py-1 lg:px-3 px-2">
              {quantity}
            </span>
            <button
              onClick={() => handleQuantityChange(labId, quantity + 1)}
              className="text-primary lg:py-2 py-1 lg:px-3 px-2 border-primary border-l font-bold"
            >
              +
            </button>
          </div>
          
          <button 
            onClick={() => removeItem(labId)} 
            className="text-red-500 hover:text-red-700"
          >
            <Trash2 size={15}/>
          </button>
        </div>
      </div>
    </div>
  );
};