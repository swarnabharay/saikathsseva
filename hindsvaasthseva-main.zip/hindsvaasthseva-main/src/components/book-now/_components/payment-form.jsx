import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import useLabTestCart from "../../../../hooks/lab-test-cart-hook";

const bookingFormSchema = z.object({
  cardNumber: z.string().length(16, "Card number must be 16 digits"),
  cardName: z.string().min(2, "Name must be at least 2 characters"),
  expiryDate: z
    .string()
    .regex(/^(0[1-9]|1[0-2])\/([0-9]{2})$/, "Expiry date must be in MM/YY format"),
  cvv: z
    .string()
    .length(3, "CVV must be 3 digits")
    .regex(/^[0-9]+$/, "CVV must contain only digits"),
  saveCard: z.boolean().optional(),
});

const PaymentForm = ({ totalAmount }) => {
  const { items } = useLabTestCart();
  const [paymentMethod, setPaymentMethod] = useState("card");
  
  const {
    register,
    handleSubmit,
    formState: { errors },
    getValues,
  } = useForm({
    resolver: zodResolver(bookingFormSchema),
    defaultValues: {
      cardNumber: "",
      cardName: "",
      expiryDate: "",
      cvv: "",
      saveCard: false,
    },
  });

  const preparePaymentData = (formData = null) => {
    const orderData = {
      orderDetails: {
        tests: items.map(item => ({
          testId: item.labId,
          testName: item.serviceName,
          quantity: item.quantity,
          price: item.price,
          subtotal: item.price * item.quantity
        })),
        totalAmount,
        totalTests: items.length,
        totalQuantity: items.reduce((acc, item) => acc + item.quantity, 0)
      },
      paymentMethod
    };

    if (paymentMethod === "card" && formData) {
      return {
        ...orderData,
        paymentDetails: {
          cardNumber: formData.cardNumber,
          cardName: formData.cardName,
          expiryDate: formData.expiryDate,
          saveCard: formData.saveCard
        }
      };
    }

    return orderData;
  };

  const onSubmit = (data) => {
    const paymentData = preparePaymentData(data);
    console.log("Payment Submission:", paymentData);
    // Here you would submit paymentData to your backend
  };

  const handleUPIPayment = () => {
    const paymentData = preparePaymentData();
    console.log("UPI Payment Submission:", paymentData);
    // Here you would submit paymentData to your backend
  };

  return (
    <div className="lg:w-[40%]">
      <div className="rounded-3xl border-[1.25px] border-primary p-6">
        <h2 className="text-2xl font-bold text-center mb-4">
          Rs. {totalAmount}.00
        </h2>
        <div className="w-full text-center mb-3">
          <span className="bg-yellow-200 text-sm font-semibold p-1 rounded mb-4">
            View detailed order
          </span>
        </div>

        {/* Payment Methods */}
        <div className="mb-4">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="paymentMethod"
              value="card"
              checked={paymentMethod === "card"}
              onChange={() => setPaymentMethod("card")}
            />
            <span className="font-semibold">Credit/Debit Card</span>
          </label>
          <p className="text-black bg-slate-200 p-2 rounded-2xl text-sm">
            Pay securely with your Bank Account using Visa or Mastercard
          </p>
        </div>

        {/* Card Payment Form */}
        {paymentMethod === "card" && (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="text-sm font-medium">Card Number</label>
              <input
                {...register("cardNumber")}
                type="text"
                className="w-full p-2 border border-gray-700 rounded-2xl"
                placeholder="XXXX XXXX XXXX XXXX"
              />
              {errors.cardNumber && (
                <p className="text-primary text-sm mt-1">
                  {errors.cardNumber.message}
                </p>
              )}
            </div>

            <div>
              <label className="text-sm font-medium">Name on Card</label>
              <input
                {...register("cardName")}
                type="text"
                className="w-full p-2 border border-gray-700 rounded-2xl"
                placeholder="Name on Card"
              />
              {errors.cardName && (
                <p className="text-primary text-sm mt-1">
                  {errors.cardName.message}
                </p>
              )}
            </div>

            <div className="flex gap-4">
              <div className="w-1/2">
                <label className="text-sm font-medium">Expire Date</label>
                <input
                  {...register("expiryDate")}
                  type="text"
                  className="w-full p-2 border border-gray-700 rounded-2xl"
                  placeholder="MM/YY"
                />
                {errors.expiryDate && (
                  <p className="text-primary text-sm mt-1">
                    {errors.expiryDate.message}
                  </p>
                )}
              </div>

              <div className="w-1/2">
                <label className="text-sm font-medium">CVV Code</label>
                <input
                  {...register("cvv")}
                  type="text"
                  className="w-full p-2 border border-gray-700 rounded-2xl"
                  placeholder="XXX"
                />
                {errors.cvv && (
                  <p className="text-primary text-sm mt-1">
                    {errors.cvv.message}
                  </p>
                )}
              </div>
            </div>

            <label className="flex items-center gap-2">
              <input {...register("saveCard")} type="checkbox" />
              <span className="text-sm">Save card for future payments</span>
            </label>

            <button
              type="submit"
              className="w-full bg-primary text-white py-3 rounded-2xl font-semibold mt-4"
            >
              Proceed with Card →
            </button>
          </form>
        )}

        {/* UPI Payment Option */}
        <div className="mb-4 mt-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="paymentMethod"
              value="upi"
              checked={paymentMethod === "upi"}
              onChange={() => setPaymentMethod("upi")}
            />
            <span className="font-semibold">UPI</span>
          </label>
          <p className="text-black bg-slate-200 p-2 rounded-2xl text-sm">
            You will be redirected to the respective UPI payment gateway to
            complete your order securely.
          </p>
        </div>

        {/* UPI Proceed Button */}
        {paymentMethod === "upi" && (
          <button
            onClick={handleUPIPayment}
            className="w-full bg-primary text-white py-3 rounded-2xl font-semibold mt-4"
          >
            Proceed with UPI →
          </button>
        )}
      </div>
    </div>
  );
};

export default PaymentForm;