import { Link } from "react-router-dom";
import useLabTestCart from "../../../hooks/lab-test-cart-hook";
import PaymentForm from "./_components/payment-form";
import { BookingItemCard } from "./_components/booking-item-card";

const BookingPage = () => {
  const { items, updateQuantity, removeItem, getTotal } = useLabTestCart();

  const handleQuantityChange = (labId, newQuantity) => {
    if (newQuantity < 1) return;
    updateQuantity(labId, newQuantity);
  };

  if (!items.length) {
    return (
      <div className="w-full max-w-screen-2xl min-h-screen mx-auto px-5 md:px-14 flex flex-col lg:flex-row justify-between gap-10 py-8">
        <div className="w-full lg:w-[60%] flex items-start flex-col">
          <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
          <div className="flex flex-col items-center justify-center w-full h-[300px] gap-4">
            <h3 className="text-2xl font-bold">Your cart is empty</h3>
            <Link to="/laboratory" className="text-blue-500 hover:underline">
              Browse Lab Tests
            </Link>
          </div>
        </div>
        <PaymentForm totalAmount={getTotal()} />
      </div>
    );
  }

  return (
    <div className="w-full max-w-screen-2xl min-h-screen mx-auto px-5 md:px-14 flex flex-col lg:flex-row justify-between gap-10 py-8">
      <div className="w-full lg:w-[60%] flex items-start flex-col">
          <Link
            to="/laboratory"
            className="text-white font-semibold bg-primary2 rounded-lg py-1 px-2"
          >
            Back
          </Link>
        <div className="w-full text-center">
          <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
        </div>
        <div className="space-y-4 w-full">
          {items?.map((item) => (
            <BookingItemCard
              key={item.labId}
              {...item}
              handleQuantityChange={handleQuantityChange}
              removeItem={removeItem}
            />
          ))}
        </div>
      </div>
      <PaymentForm totalAmount={getTotal()} />
    </div>
  );
};

export default BookingPage;
