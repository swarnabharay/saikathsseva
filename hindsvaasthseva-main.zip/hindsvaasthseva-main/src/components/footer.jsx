import { Link } from 'react-router-dom';
import SiteLogo from './logo'

const data = [
  {
    name: "About us",
    link: ""
  },
  {
    name: "Privicy Policy",
    link: "/privacy-policy"
  },
  {
    name: "Terms and Conditions",
    link: "/terms-conditions"
  },
  {
    name: "Contact us",
    link: ""
  },
]

const Footer = () => {
  return (
      <div className="w-full max-w-screen-2xl mx-auto px-5 md:px-8 flex md:flex-row flex-col items-center gap-10 py-6 border-t-2 border-primary mt-5"> 
          <div className="md:w-[30%] w-full">
          <SiteLogo/>
          </div>
          <div className="md:w-[70%] w-full flex md:items-center md:justify-end">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
            {data.map((item, index) => (
              <Link key={index} to={item.link} className="font-semibold md:text-center text-primary text-start">{item.name}</Link>
            ))}
          </div>
          </div>
      </div>
  )
}

export default Footer;
