import { Link } from "react-router-dom";
//@ts-ignore
import Logo from "/logo.png";

const SiteLogo = () => {
  return (
    <Link to="/" className="shrink-0">
      <img src={Logo} alt="Logo" className="h-12 md:px-2" />
    </Link>
  );
};

export default SiteLogo;
