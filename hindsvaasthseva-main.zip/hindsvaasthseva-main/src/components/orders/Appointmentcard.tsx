import React from "react";

// Define the type for an individual appointment
type Appointment = {
  id: number;
  date: string; // Can be a string or Date if you prefer working with Date objects
  startTime: string;
  endTime: string;
  status: string;
  // If you have other properties, add them here
};

// Define the prop type for the component
interface AppointmentCardProps {
  appointment: Appointment[]; // Expecting an array of Appointment objects
}

const AppointmentCard: React.FC<AppointmentCardProps> = ({ appointment }) => {
  return (
    <div>
      {appointment.length === 0 ? (
        <div>No data</div>
      ) : (
        appointment.map((arr) => (
          <div key={arr.id}>
            <div className="px-6 py-4">
              <div className="font-bold text-xl mb-2 text-gray-800">
                Appointment Details
              </div>
              <p className="text-gray-700 text-base">
                <strong>Doctor:</strong>
              </p>
              <p className="text-gray-700 text-base">
                <strong>Date:</strong> {arr.date}
              </p>
              <p className="text-gray-700 text-base">
                <strong>Time:</strong> {arr.startTime} - {arr.endTime}
              </p>
              <p className="text-gray-700 text-base">
                <strong>Location:</strong>
              </p>
            </div>
            <div className="px-6 pt-4 pb-2"></div>
          </div>
        ))
      )}
    </div>
  );
};

export default AppointmentCard;
