import React, { useState, useEffect } from "react";
import AppointmentCard from "./Appointmentcard";

// Define the types for the API response
type ResponseItem = {
  id: number;
  date: string;  // Could be a Date type if you prefer to work with Date objects
  startTime: string;
  endTime: string;
  status: string;
  // Add any other fields as necessary
};

type ApiResponse = {
  message: string;
  response: ResponseItem[];
};

const FetchDataComponent: React.FC = () => {
  // State to store the API response
  const [data, setData] = useState<ApiResponse | null>(null);
  // State for loading indication
  const [loading, setLoading] = useState<boolean>(true);
  // State for error handling
  const [error, setError] = useState<string | null>(null);

  // useEffect to call the API when the component mounts
  useEffect(() => {
    const url = import.meta.env.VITE_BASE_API_URL; // URL from environment variables
    // Make the API call
    fetch(`${url}/appointment/get/1`)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json(); // Parse JSON response
      })
      .then((data: ApiResponse) => {
        console.log(data.response, "**");
        setData(data); // Set the API response in state
        setLoading(false); // Set loading to false after the data is fetched
      })
      .catch((error: Error) => {
        setError(error.message); // Set error message if the API call fails
        setLoading(false); // Stop loading even in case of error
      });
  }, []); // Empty dependency array makes sure the effect runs only once when the component mounts

  // Handle loading, error, and display data
  if (loading) {
    return <div>Loading...</div>; // Show loading indicator while waiting for the response
  }

  if (error) {
    return <div>Error: {error}</div>; // Show error message if API call fails
  }

  // Once the data is fetched, display it
  return (
    <div>
      <h1>API Response Data:</h1>
      {data?.message === "success" ? (
        <AppointmentCard appointment={data.response} />
      ) : (
        <div>No data available</div>
      )}
    </div>
  );
};

export default FetchDataComponent;
