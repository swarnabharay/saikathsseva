
const Skeleton = () => {
  return (
    <div className="flex flex-col gap-2">
      <div className="h-[200px] w-[300px] bg-gray-200 animate-pulse rounded-2xl"></div>
      <div className="h-[20px] w-[180px] bg-gray-200 animate-pulse rounded-2xl"></div>
      <div className="h-[20px] w-[150px] bg-gray-200 animate-pulse rounded-2xl"></div>
      <div className="h-[20px] w-[150px] bg-gray-200 animate-pulse rounded-2xl"></div>
    </div>
  );
}

function RowPlaceHolder() {
  return (
    <div className="w-full">
      <div
        className="grid grid-cols-1 md:grid-cols-3 overflow-x-auto gap-5"
        style={{
          scrollbarWidth: "none", // Firefox
          msOverflowStyle: "none", // IE/Edge
        }}
      >
        {
          Array(3).fill().map((_, index) => (
            <div key={index} className="px-2 flex-shrink-0">
              <Skeleton />
            </div>
          ))
        }
      </div>
    </div>
  );
}

export default RowPlaceHolder;
