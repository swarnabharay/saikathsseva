import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className='min-h-screen w-full max-w-screen-2xl mx-auto px-5 md:px-14 flex items-center justify-center'>
      <div className="bg-secondary/20 border border-primary rounded-xl p-5 md:p-8 w-full">
        <h1 className="text-4xl text-primary font-bold mb-8">Privacy Policy - Hind Svaasth Seva</h1>
        
        <p className="text-gray-700 mb-6">
          At Hind Svaasth Seva, we prioritize the protection of your personal information. This Privacy Policy outlines our practices for collecting, using, and safeguarding your data when you use our healthcare platform.
        </p>

        <div className="space-y-8">
          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">1. Information We Collect</h2>
            <p className="text-gray-700">
              We collect information necessary for providing healthcare services, including:
              - Personal identification information
              - Medical history and records
              - Appointment and booking details
              - Payment information
              All data collection is done with explicit user consent.
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">2. How We Use Your Information</h2>
            <p className="text-gray-700">
              Your information is used to:
              - Process appointments and bookings
              - Provide healthcare services
              - Improve our platform
              - Communicate important updates
              - Ensure compliance with healthcare regulations
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">3. Data Protection</h2>
            <p className="text-gray-700">
              We implement robust security measures including encryption, firewalls, and access controls. Our security practices comply with HIPAA, GDPR, and other relevant healthcare data protection standards.
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">4. Your Rights</h2>
            <p className="text-gray-700">
              You have the right to:
              - Access your personal data
              - Request corrections to your data
              - Delete your account
              - Opt-out of marketing communications
              - File complaints about data handling
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">5. Third-Party Sharing</h2>
            <p className="text-gray-700">
              We only share your information with third parties when:
              - Required for providing healthcare services
              - Required by law
              - You have given explicit consent
              All third-party partners are bound by strict confidentiality agreements.
            </p>
          </section>

          <section className='rounded-xl bg-secondary/50 p-5'>
            <h2 className="text-2xl text-primary font-semibold mb-3">Contact Us</h2>
            <p className="text-gray-700">
              If you have questions about our privacy practices, please contact our Data Protection Officer at privacy@hindsvaasthseva.com or call us at [Your Phone Number].
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;