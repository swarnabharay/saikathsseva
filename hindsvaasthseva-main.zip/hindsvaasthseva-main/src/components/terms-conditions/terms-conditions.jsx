import React from 'react';

const TermsConditions = () => {
  return (
    <div className='min-h-screen w-full max-w-screen-2xl mx-auto px-5 md:px-14 flex items-center justify-center'>
      <div className="bg-secondary/20 border border-primary rounded-xl p-5 md:p-8 w-full">
        <h1 className="text-4xl text-primary font-bold mb-8">Terms and Conditions - Hind Svaasth Seva</h1>
        
        <p className="text-gray-700 mb-6">
          Welcome to Hind Svaasth Seva. By accessing or using our platform, you agree to be bound by these Terms and Conditions. Please read them carefully before using our services.
        </p>

        <div className="space-y-8">
          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">1. Acceptance of Terms</h2>
            <p className="text-gray-700">
              By accessing our platform, you acknowledge that you have read, understood, and agree to be bound by these terms. If you do not agree with any part of these terms, you must not use our services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">2. Service Description</h2>
            <p className="text-gray-700">
              Hind Svaasth Seva provides an online platform for:
              - Booking medical appointments
              - Scheduling diagnostic tests
              - Accessing medical reports
              - Consulting with healthcare providers
              We reserve the right to modify or discontinue any service without notice.
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">3. User Responsibilities</h2>
            <p className="text-gray-700">
              Users must:
              - Provide accurate information
              - Maintain account security
              - Comply with appointment schedules
              - Pay for services as agreed
              - Not misuse the platform
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">4. Medical Disclaimer</h2>
            <p className="text-gray-700">
              Our platform facilitates healthcare services but does not provide medical advice. All medical decisions should be made in consultation with qualified healthcare providers.
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">5. Payment Terms</h2>
            <p className="text-gray-700">
              - Payments must be made at the time of booking
              - Cancellation policies apply as specified
              - Refunds are processed according to our refund policy
              - All applicable taxes will be added to the final amount
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">6. Limitation of Liability</h2>
            <p className="text-gray-700">
              We strive to provide reliable services but are not liable for:
              - Technical difficulties or service interruptions
              - Medical outcomes
              - Third-party services
              - Indirect or consequential damages
            </p>
          </section>

          <section>
            <h2 className="text-2xl text-primary font-semibold mb-3">7. Changes to Terms</h2>
            <p className="text-gray-700">
              We reserve the right to modify these terms at any time. Continued use of our platform after changes constitutes acceptance of the modified terms.
            </p>
          </section>

          <section className='rounded-xl bg-secondary/50 p-5'>
            <h2 className="text-2xl text-primary font-semibold mb-3">Contact Information</h2>
            <p className="text-gray-700">
              For questions about these terms, please contact us at legal@hindsvaasthseva.com or call [Your Phone Number].
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default TermsConditions;