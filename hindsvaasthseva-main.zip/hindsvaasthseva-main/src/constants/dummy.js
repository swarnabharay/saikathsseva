export const laboratories = [
  {
    laboratoryId: "15526637",
    laboratoryName: "Ohio Medical Center",
    location: "Newtown",
    rating: "4.5",
    description:
      "A renowned laboratory providing excellent healthcare services with a team of experienced professionals.",
    highlights: "24/7 Emergency Services, Specialized Care, Advanced Equipment",
    imageUrl: "https://example.com/image1.jpg",
  },
  {
    laboratoryId: "15526638",
    laboratoryName: "Sunrise Health Center",
    location: "Green Valley",
    rating: "4.8",
    description:
      "A state-of-the-art facility focusing on patient-centric healthcare and innovative treatments.",
    highlights: "Multi-Specialty Care, World-Class Surgeons, Wellness Programs",
    imageUrl: "https://example.com/image2.jpg",
  },
  {
    laboratoryId: "15526639",
    laboratoryName: "Lakeside Laboratory",
    location: "Lakeside City",
    rating: "4.7",
    description:
      "Comprehensive care for all your medical needs with a focus on recovery and rehabilitation.",
    highlights: "Rehabilitation Services, Pediatric Care, Affordable Packages",
    imageUrl: "https://example.com/image3.jpg",
  },
  {
    laboratoryId: "15526640",
    laboratoryName: "Harmony Medical Institute",
    location: "Downtown",
    rating: "4.6",
    description:
      "Cutting-edge medical technology and compassionate care for a healthier tomorrow.",
    highlights: "Cardiology, Neurology, State-of-the-Art Operating Theaters",
    imageUrl: "https://example.com/image4.jpg",
  },
  {
    laboratoryId: "15526641",
    laboratoryName: "Greenfield Clinic",
    location: "Suburbia",
    rating: "4.4",
    description:
      "A family-friendly clinic dedicated to preventative care and wellness for all age groups.",
    highlights: "Preventative Care, Family Medicine, On-Site Pharmacy",
    imageUrl: "https://example.com/image5.jpg",
  },
];


export const labTests = [
  {
    labId: "lab001",
    serviceName: "CBC(Complete Blood Count)",
    price: 129,
    duration: "1 day",
    description:
      "Complete analysis of blood cells, including red cells, white cells, and platelets.",
  },
  {
    labId: "lab002",
    serviceName: "Blood Chemistry Panel",
    price: 129,
    duration: "1-2 days",
    description:
      "Comprehensive evaluation of blood chemistry, including glucose, electrolytes, and kidney function.",
  },
  {
    labId: "lab003",
    serviceName: "Urinalysis",
    price: 129,
    duration: "1 day",
    description:
      "Analysis of urine components for detecting various disorders and conditions.",
  },
  {
    labId: "lab004",
    serviceName: "Chest X-Ray",
    price: 129,
    duration: "Same day",
    description:
      "Imaging of the chest to examine lungs, heart, and surrounding structures.",
  },
  {
    labId: "lab005",
    serviceName: "Electrocardiogram (ECG)",
    price: 129,
    duration: "30 minutes",
    description:
      "Recording of the electrical activity of the heart to detect cardiac abnormalities.",
  },
  {
    labId: "lab006",
    serviceName: "Magnetic Resonance Image",
    price: 129,
    duration: "1-2 hours",
    description:
      "Detailed imaging using magnetic fields to visualize internal body structures.",
  },
  {
    labId: "lab007",
    serviceName: "Liver Function Test",
    price: 129,
    duration: "1 day",
    description:
      "Evaluation of liver health through blood tests measuring enzymes and proteins.",
  },
  {
    labId: "lab008",
    serviceName: "Kidney Function Test",
    price: 129,
    duration: "1 day",
    description:
      "Assessment of kidney function through blood and urine analysis.",
  },
  {
    labId: "lab009",
    serviceName: "Thyroid Panel",
    price: 149,
    duration: "1-2 days",
    description:
      "Comprehensive evaluation of thyroid hormone levels and function.",
  },
  {
    labId: "lab010",
    serviceName: "Lipid Profile",
    price: 119,
    duration: "1 day",
    description:
      "Measurement of blood cholesterol levels to assess cardiovascular risk.",
  },
  {
    labId: "lab011",
    serviceName: "Hemoglobin A1C",
    price: 99,
    duration: "1 day",
    description: "Long-term blood glucose monitoring for diabetes management.",
  },
  {
    labId: "lab012",
    serviceName: "Vitamin D Test",
    price: 159,
    duration: "2-3 days",
    description:
      "Evaluation of vitamin D levels to assess bone health and immune function.",
  },
];

export const laboratoryLabServices = {
  15526637: ["lab001", "lab002", "lab003", "lab004", "lab005", "lab009"],
  15526638: ["lab001", "lab002", "lab006", "lab007", "lab008", "lab010"],
  15526639: ["lab001", "lab003", "lab005", "lab007", "lab009", "lab011"],
  15526640: ["lab002", "lab004", "lab006", "lab008", "lab010", "lab012"],
  15526641: ["lab001", "lab003", "lab005", "lab007", "lab009", "lab012"],
};
