import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import AuthLayout from "./Layouts/AuthLayout.jsx";
import MainLayout from "./Layouts/MainLayout.jsx";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import App from "./App.jsx";
import AuthPage from "./components/Auth/AuthPage.jsx";
import HospitalInfo from "./components/HospitalInfo/HospitalInfoPage.jsx";
import DoctorsPage from "./components/Doctors/DoctorsPage.jsx";
import ProfilePage from "./components/Profile/ProfilePage.jsx";
import LoginPage from "./components/Admin/LoginPage.jsx";
import EditHospital from "./components/Admin/EditHospital2.jsx";
import AddDoctor from "./components/Admin/AddDoctor.jsx";
import ManageDoctors from "./components/Admin/ManageDoctors.jsx";
import Appointments from "./components/orders/Appointments"
import { Navigate } from "react-router-dom";
import PropTypes from "prop-types";
import AppointmentPage from "./components/DoctorAppointment/AppointmentPage.jsx";
import TermsConditions from "./components/terms-conditions/terms-conditions.jsx";
import PrivacyPolicy from "./components/terms-conditions/privacy-policy.jsx";
import BookingPage from "./components/book-now/lab-test-booking-page.jsx";
import LabtestPage from "./components/Laboratory/lab-test-page.jsx";
import LaboratoryInfoPage from "./components/Laboratory/_components/laboratory-details-info.jsx";
import BookingPaymentForm from "./components/DoctorAppointment/_components/booking-payment-form.jsx";




// Build a protected route component to protect the profile page from unauthorized access. The component will check if the user is authenticated before rendering the children components. If the user is not authenticated, it will redirect to the authentication page.
const ProtectedRoute = ({ children }) => {
  const token = localStorage.getItem("token");

  // Check if the token exists and is valid (you can include an expiry check here)
  if (!token) {
    return <Navigate to="/auth" replace />; // Redirect to home or login page
  }

  return children;
};

ProtectedRoute.propTypes = {
  children: PropTypes.node.isRequired,
};
export default ProtectedRoute;


// Created a browser router with the routes for the application. The router will define the layout and the children components for each route. The ProtectedRoute component will be used to protect the profile page route.
const router = createBrowserRouter([

  // main route
  {
    path: "/",
    element: <MainLayout />,
    children: [
      {
        path: "",
        element: <App />,
      },
      {
        path: "/profile",
        element: (
          <ProtectedRoute>
            <ProfilePage />
          </ProtectedRoute>
        ),
      },
      {
        path: "/hospitalinfo/:id",
        element: <HospitalInfo />,
      },
      {
        path: "/search-doctors",
        element: <DoctorsPage />,
      },
      {
        path: "/book-appointment/:doctorId/:hospitalId",
        element: <AppointmentPage />,
      },      
      {
        path:"/orders",
        element:<Appointments></Appointments>
      },
      {
        path:"/laboratory",
        element:<LabtestPage/>
      },
      {
        path:"/terms-conditions",
        element:<TermsConditions/>
      },
      {
        path:"/privacy-policy",
        element:<PrivacyPolicy/>
      },
      {
        path:"/laboratory/:id",
        element:<LaboratoryInfoPage/>
      },
      {
        path:"/book-now",
        element:<BookingPage/>
      },
      {
        path:"/appointment-book",
        element:<BookingPaymentForm/>
      },
    ],
  },
  // auth route
  {
    path: "auth",
    element: <AuthLayout />,
    children: [
      {
        path: "",
        element: <AuthPage />,
      },
    ],
  },
  // admin route
  {
    path: "/admin",
    children: [
      {
        path: "",
        element: <LoginPage />,
      },
      {
        path: "login",
        element: <LoginPage />,
      },
      {
        path: "edithospital",
        element: <EditHospital />,
      },
      {
        path: "adddoctor",
        element: <AddDoctor />,
      },
      {
        path: "managedoctor",
        element: <ManageDoctors />,
      },
    ],
  },
]);

createRoot(document.getElementById("root")).render(
  <StrictMode>
      <RouterProvider router={router} />
  </StrictMode>
);
