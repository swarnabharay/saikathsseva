import axios from "axios";

const baseApiUrl = import.meta.env.VITE_BASE_API_URL;

export const bookAppointment = async (data) => {
  try {
    const response = await axios.post(`${baseApiUrl}/appointment/book`, data);
    return response;
  } catch (error) {
    return error.response;
  }
};

export const getBookedAppointments = async (userId) => {
  try {
    const response = await axios.get(`${baseApiUrl}/appointment/get/${userId}`);
    return response;
  } catch (error) {
    return error.response;
  }
};

export default {
    bookAppointment: bookAppointment,
    getBookedAppointments: getBookedAppointments
};
