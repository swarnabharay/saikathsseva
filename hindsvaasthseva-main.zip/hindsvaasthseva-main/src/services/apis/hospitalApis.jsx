import axios from "axios";

const baseApiUrl = import.meta.env.VITE_BASE_API_URL;

export const getHospitalById = async (id) => {
  try {
    const response = await axios.get(`${baseApiUrl}/hospitals/${id}`);
    return response;
  } catch (error) {
    return error.response;
  }
};

export const getAllHospital = async () => {
  try {
    const response = await axios.get(`${baseApiUrl}/hospitals`);
    return response;
  } catch (error) {
    return error.response;
  }
};

export const getAllAvailableDepartments = async () => {
  try {
    const response = await axios.get(`${baseApiUrl}/department`);
    return response;
  } catch (error) {
    return error.response;
  }
};

export default {
  getHospitalById,
  getAllHospital,
  getAllAvailableDepartments,
};
