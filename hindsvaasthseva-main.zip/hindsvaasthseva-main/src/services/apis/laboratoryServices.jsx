import axios from "axios";

const baseApiUrl = import.meta.env.VITE_BASE_API_URL;

export const getAllLaboratories = async () => {
  try {
    const response = await axios.get(`${baseApiUrl}/laboratory`);
    return response;
    
  } catch (error) {
    return error.response;
  }
};


export default {
    getAllLaboratories
};
