const url= import.meta.env.VITE_BASE_API_URL;
export default async function get(){
    console.log("in local server")
    const res=await fetch(`${url}/appointment/get/1`).catch(err=>{console.log(err)})
    const json=await res.json()
    console.log(json,"&&")
    return res
}