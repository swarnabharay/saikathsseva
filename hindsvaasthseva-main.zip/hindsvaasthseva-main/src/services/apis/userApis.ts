import axios, { AxiosResponse, AxiosError } from "axios";

// Get the API URLs from environment variables
const userApiUrl =import.meta.env.VITE_USER_API_URL as string;
const userUpdateApiUrl = import.meta.env.VITE_USER_UPDATE_API_URL as string;
// Define types for the parameters
interface GetUserParams {
  token: string;
  email: string;
}

interface UpdateUserParams {
  token: string;
  email: string;
  data: Record<string, any>; // Replace `any` with a more specific type if needed
}

// Define the structure of the response from the `getUser` and `updateUser` API
interface UserResponse {
  // Define the expected response structure here
  name: string;
  id: any;
}

// Function to fetch user data
export const getUser = async ({
  token,
  email,
}: GetUserParams): Promise<AxiosResponse<UserResponse> | undefined> => {
  try {
    const response: AxiosResponse<UserResponse> = await axios.get(
      `${userApiUrl}/${email}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    return response;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error("Error fetching user:", error.response);
      return error.response;
    } else {
      console.error("An unknown error occurred:", error);
    }
  }
};

// Function to update user data
export const updateUser = async ({
  token,
  email,
  data,
}: UpdateUserParams): Promise<AxiosResponse<UserResponse> | undefined> => {
  console.log(data);
  try {
    const response: AxiosResponse<UserResponse> = await axios.put(
      `${userUpdateApiUrl}/${email}`,
      data,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    console.log(response);
    return response;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error("Error updating user:", error.response);
      return error.response;
    } else {
      console.error("An unknown error occurred:", error);
      return undefined;
    }
  }
};
