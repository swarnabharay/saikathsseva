import { jwtDecode } from "jwt-decode";

const isTokenExpired = (token) => {
  if (!token) return true; // If no token, consider it expired
  try {
    const { exp } = jwtDecode(token); // Decode the token
    const currentTime = Date.now() / 1000; // Current time in seconds
    return exp < currentTime; // Compare expiration time with current time
  } catch (error) {
    console.error("Error decoding token:", error);
    return true; // If decoding fails, consider it expired
  }
};

export default isTokenExpired;
